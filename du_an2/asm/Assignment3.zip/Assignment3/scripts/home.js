'use strict'
let messger=document.getElementById('welcome-message')
let logout=document.getElementById('main-content')
let login=document.getElementById('login-modal')

let usercurrent=getusercurrent()
if(getusercurrent()!==null){
    usercurrent=getusercurrent() 
    messger.innerHTML=`Welcome ${usercurrent[0].firstName}`
    login.style.display='none'
}else{
    logout.style.display= 'none'
}


document.getElementById('btn-logout').addEventListener('click',function(){
    logout.style.display='none'
    login.style.display='block'
    removeusercurrent()
})

