'use strict'
//
let user=[];

//nhận dữ liệu user từ storage
getFromStorage()!==null?user=getFromStorage():user;
console.log(user.length)
//chuyển đổi dữ liệu obj sang dữ liệu class instanct
console.log(user)
for(let i= 0 ;i<=user.length-1;i++){
function instanceUser(user) {
    console.log(user[i].firstName)
	const user1 = new User(user[i].firstName, user[i].lastName, user[i].userName, user[i].Password)
    console.log('user1', user1)
	return user1
}
    
    user[i]=instanceUser(user)
}
console.log(user)
const inputfirstname=document.getElementById('input-firstname');
const inputlastname= document.getElementById('input-lastname');
const inputusername= document.getElementById('input-username');
const inputpassword= document.getElementById('input-password');
const inputpasswordconfim=document.getElementById('input-password-confirm');
const btnsumit= document.getElementById('btn-submit');


btnsumit.addEventListener('click',function(){
    const fistName= inputfirstname.value
    const lastName= inputlastname.value
    const UserName=inputusername.value;
    const password= inputpassword.value;
    const confirm= inputpasswordconfim.value;

    // neus người dùng chưa nhập thông tin thì thông báo 
    if (fistName && lastName&&UserName&&password!==''&&confirm!==''){
        console.log('good')
        /*biến check nhận về giá trị true nếu user trùng với user
        đã có hoặc nhận giá trị false nếu không trùng user*/
        const check= user.filter(function(arr){
            if (UserName==arr.UserName){return true}{return false}
        })
        //nếu trùng với giá trị user đã có thì thông báo
        if(check){
            //nếu password dưới 8 kí tự thì thông báo
            if(password.length>8){
                //nếu nhập lại password không chính xác thì thông báo
                if (password===confirm){
                    //lưu dữ liệu người dùng vừa nhập
                    const  usernew = new User(`${fistName}`,`${lastName}`,`${UserName}`,`${password}`);
                    user.push(usernew)
                    window.location='login.html'
                    saveToStorage(user)
                }else{alert('nhập lại password chưa đúng')}
            }else{alert('Password phải có nhiều hơn 8 kí tự')}
        }else{alert('UserName trùng với người dùng khác')}
    }else{alert('bạn cần nhập đầy đủ thông tin')}

})