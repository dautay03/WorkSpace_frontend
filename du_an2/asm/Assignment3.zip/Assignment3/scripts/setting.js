'use strict'

let setting = []

let submit= document.getElementById('btn-submit')
let inputpagesize= document.getElementById('input-page-size')
let inputCategory= document.getElementById('input-category')


submit.addEventListener('click',function(){
    if(inputpagesize.value!=''&&inputCategory.value!='General'){
        setting=[{size:inputpagesize.value,category:inputCategory.value}]
        saveTosettingnews(setting)
    }else{alert('Chưa nhập đủ thông tin')}

})



