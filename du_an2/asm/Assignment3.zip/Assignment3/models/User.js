'use strict'
class User{
    constructor(fistName,lastname,UserName, password){
        this.firstName=fistName;
        this.lastName=lastname;
        this.userName=UserName;
        this.Password=password;
    }
}
