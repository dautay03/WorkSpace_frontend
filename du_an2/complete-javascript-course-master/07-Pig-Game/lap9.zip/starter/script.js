'use strict';
// chọn ddối tượng
const rollbt = document.querySelector('.btn--roll');
const newbt = document.querySelector('.btn--new');
const holdbt = document.querySelector('.btn--hold');
const player1= document.querySelector('.player--0');
const player2= document.querySelector('.player--1');
const  dice= document.querySelector('.dice');
const score0el=document.querySelector('#score--0');
const score1el=document.querySelector('#score--1');

//khai báo biến
let score0= 0;
let score1= 0;

//giá trị khởi động
score0el.textContent=score0;
score1el.textContent=score1;
dice.classList.add('.hidden');

//tạo sự kiện đổ xúc sắc
rollbt.addEventListener('click',function(){
    //tạo giá trị khi đổ xúc sắc
    let dicenumber= Math.trunc(Math.random()*6+1);
    //hiển thị xúc sắc
    
    dice.classList.remove('.hidden')
    dice.src=`dice-${dicenumber}.png`;
    //kiểm tra xem xúc sắc có bằng 1 ko
})

